// src/main/java/com/jankovic/fastfood/dto/OrderRequestDTO.java
package com.jankovic.fastfood.dto;

import lombok.Data;
import java.util.List;

@Data
public class OrderRequestDTO {
    private List<Item> items;

    @Data
    public static class Item {
        private Long menuItemId;
        private int quantity;
    }
}
