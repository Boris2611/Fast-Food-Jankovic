package com.jankovic.fastfood.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderResponseDTO {
    private Long id;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime estimatedReady;
    private List<OrderItemResponseDTO> orderItems;

    @Data
    public static class OrderItemResponseDTO {
        private Long id;
        private String naziv;
        private int quantity;
    }
}
