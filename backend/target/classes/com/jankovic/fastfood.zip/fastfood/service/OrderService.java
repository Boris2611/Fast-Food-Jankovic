package com.jankovic.fastfood.service;

import com.jankovic.fastfood.dto.OrderResponseDTO;
import com.jankovic.fastfood.entity.Order;
import com.jankovic.fastfood.entity.OrderItem;
import com.jankovic.fastfood.entity.OrderStatus;
import com.jankovic.fastfood.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order create(Order order) {
        order.setCreatedAt(LocalDateTime.now());
        order.setEstimatedReady(null);
        order.setStatus(OrderStatus.POSLATA);
        return orderRepository.save(order);
    }

    public List<Order> findByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public Optional<Order> findById(Long id) {
        return orderRepository.findById(id);
    }

    public List<OrderResponseDTO> findDTOByUserId(Long userId) {
        List<Order> orders = findByUserId(userId);
        return orders.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public Order updateStatus(Order order, OrderStatus newStatus, Integer readyInMinutes) {
        OrderStatus oldStatus = order.getStatus();

        if (!isValidTransition(oldStatus, newStatus)) {
            throw new IllegalArgumentException("Nevalidan prelaz statusa: " + oldStatus + " -> " + newStatus);
        }

        order.setStatus(newStatus);

        if (readyInMinutes != null && readyInMinutes > 0) {
            order.setEstimatedReady(LocalDateTime.now().plusMinutes(readyInMinutes));
        } else if (newStatus == OrderStatus.POSLATA) {
            order.setEstimatedReady(null);
        }

        return orderRepository.save(order);
    }

    private boolean isValidTransition(OrderStatus oldStatus, OrderStatus newStatus) {
        if (newStatus == OrderStatus.OTKAZANA) {
            return true;
        }

        return switch (oldStatus) {
            case POSLATA -> newStatus == OrderStatus.PRIHVACENA;
            case PRIHVACENA -> newStatus == OrderStatus.U_PRIPREMI;
            case U_PRIPREMI -> newStatus == OrderStatus.GOTOVA;
            case GOTOVA -> newStatus == OrderStatus.ISPORUCENA;
            case ISPORUCENA, OTKAZANA -> false;
            default -> false;
        };
    }

    // DTO mapping
    private OrderResponseDTO mapToDTO(Order order) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setId(order.getId());
        dto.setStatus(order.getStatus().name());
        dto.setCreatedAt(order.getCreatedAt());
        dto.setEstimatedReady(order.getEstimatedReady());
        dto.setOrderItems(order.getOrderItems().stream()
                .map(this::mapOrderItemToDTO)
                .collect(Collectors.toList()));
        return dto;
    }

    private OrderResponseDTO.OrderItemResponseDTO mapOrderItemToDTO(OrderItem orderItem) {
        OrderResponseDTO.OrderItemResponseDTO itemDTO = new OrderResponseDTO.OrderItemResponseDTO();
        itemDTO.setId(orderItem.getId());
        itemDTO.setQuantity(orderItem.getQuantity());
        if (orderItem.getMenuItem() != null) {
            itemDTO.setNaziv(orderItem.getMenuItem().getNaziv());
        } else {
            itemDTO.setNaziv("Nepoznat proizvod");
        }
        return itemDTO;
    }
}
