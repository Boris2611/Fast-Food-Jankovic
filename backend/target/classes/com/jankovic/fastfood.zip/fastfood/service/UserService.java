// UserService.java
package com.jankovic.fastfood.service;

import com.jankovic.fastfood.entity.User;
import com.jankovic.fastfood.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User register(User user) {
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("kupac");  // automatski dodeljujemo rolu kupac
        }
        // kasnije i hashiranje lozinke pre čuvanja
        return userRepository.save(user);
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
}
